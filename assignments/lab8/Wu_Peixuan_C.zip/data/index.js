//Here you will require data files and export them as used in previous labs

const peopleData = require('./people');


module.exports = {
  people: peopleData
};
